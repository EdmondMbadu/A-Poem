
package stacks;

import java.util.Scanner;
import java.util.Stack;
import java.util.regex.Pattern;

/**
 *
 * @author ramon
 */
public class Calculator {
    
    public static final Pattern UNSIGNED_DOUBLE = 
            Pattern.compile("((\\d+\\.?\\d*)|(\\.\\d+))([Ee][-+]?\\d+)?.*?");
    public static final Pattern CHARACTER = Pattern.compile("\\S.*?");
    
    /**
     * Evaluates a mathematical expression.
     * @param expression mathematical expression
     * @return result of mathematical expression
     */
    public static double evaluate(String expression){
        
        Stack<Double> numbers = new Stack<>();
        Stack<Character> operations = new Stack<>();
        
        // convert String expression into a scanner
        Scanner input = new Scanner(expression);
        
        // string that will be used to temporarily store the 
        // next number or operation in the expression
        String next;
        
        // loop through the mathematical expression
        while (input.hasNext()){
            // if the next item in the mathematical expression is a number
            if (input.hasNext(UNSIGNED_DOUBLE)){
                // get the number and push it onto the number stack
                next = input.findInLine(UNSIGNED_DOUBLE);
                numbers.push(new Double(next));
            } else{
                // get the character
                next = input.findInLine(CHARACTER);
                switch(next.charAt(0)){
                    case '+' :
                    case '-' :
                    case '*' :
                    case '/' :
                        // if the character is an operation, push it onto
                        // the operation stack
                        operations.push(next.charAt(0));
                        break;
                    case ')' :
                        // if the character is a ), evaluate the stack
                        evaluateStackTops(numbers, operations);
                        break;
                    case '(' :
                        // if the next item is a left parenthesis,
                        // disregard it
                        break;
                    default : 
                        // it an ivalid character ws present in mathematical 
                        // expression, thow an exception 
                        throw new IllegalArgumentException("Illegal Character!");
                }
            }
        }
        
        // if the numbers stack has more than 1 number, then we were given 
        // an illegal expression
        if (numbers.size() != 1)
            throw new IllegalArgumentException("Illegal input expression!");
        
        // pop and return the last number on the number stack
        return numbers.pop();
    }
    
    /**
     * Performs calculations using numbers and operations
     * in stacks.
     * @param numbers number stack
     * @param operations operation stack
     */
    public static void evaluateStackTops(Stack<Double> numbers, 
            Stack<Character> operations){
        
        // make sure stacks are set up correctly
        if (numbers.size() < 1 || operations.empty())
            throw new IllegalArgumentException("Illegal Expression");
        
        // pop two numbers
        double operand2 = numbers.pop();
        double operand1 = numbers.pop();
        
        // pop an operation and evaluate it
        switch(operations.pop()){
            case '+' :
                numbers.push(operand1 + operand2);
                break;
            case '-' :
                numbers.push(operand1 - operand2);
                break;
            case '*' :
                numbers.push(operand1 * operand2);
                break;
            case '/' :
                // if the popped operation is /, perform the division
                // and upsh the result onto the number stack
                numbers.push(operand1 / operand2);
                break;
            default:
                throw new IllegalArgumentException("Illegal Operation!");
        }
    }
}
