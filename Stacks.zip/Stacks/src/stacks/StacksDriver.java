
package stacks;

import java.util.Stack;

/**
 *
 * @author ramon
 */
public class StacksDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        testPush();
        testEmpty();
        testPeek();
        testPop();
        testSearch();
        testRemoveElementAt();
        
        System.out.println("Are parenthesis balanced ? "
                + BalancedParenthesis.isBalanced("{X+Y"));
        System.out.println("Are parenthesis balanced ? "
                + BalancedParenthesis.isBalanced("{X+Y)"));
        System.out.println("Are parenthesis balanced ? "
                + BalancedParenthesis.isBalanced("({X+Y}*Z)"));
        System.out.println("Are parenthesis balanced ? "
                + BalancedParenthesis.isBalanced("[A+B]*({X+Y}*Z)"));
        */ 
        
        System.out.println("(((6+9)/3)*(6-4))="
                + Calculator.evaluate("(((6+9)/3)*(6-4))"));
    }
    
    public static void testPush(){
        
        System.out.println("*** TESTING PEEK METHOD ***");
        
        Stack<Integer> s = new Stack<>();
        s.push(3);
        s.push(4);
        s.push(5);
        s.push(6);
    }
    
    public static void testEmpty(){
        
        System.out.println("\n*** TESTING EMPTY METHOD ***");
        Stack<String> s = new Stack();
        System.out.println("Is the stack empty? " + s.empty());
        
        s.push("Java");
        s.push("Red");
        s.push("Blue");
        
        System.out.println("Is the stack empty? " + s.empty());
        System.out.println("Stack contains : " + s);
        
    }
    
    public static void testPeek(){
        
        System.out.println("\n*** TESTING PEEK METHOD ***");
        
        Stack<String> top = new Stack();
        
        top.push("time");
        top.push("how");
        top.push("new");
        top.push("made");
        //top.push(2);
        
        System.out.println(top.peek() + " is at the top of the stack");
        
        Stack<String> empty = new Stack();
        
        //empty.peek();
        
        System.out.println("Top stack contains: " + top + ", and has a size"
                + " of " + top.size());
        System.out.println("At the top of Top stack is: " + top.peek());
        top.removeElementAt(0);
        System.out.println("Top stack now contains: " + top);
    }
    
    public static void testPop(){
        
        System.out.println("\n*** TESTING POP METHOD ***");
        
        Stack<String> tP = new Stack<>();
        
        tP.push("Data");
        tP.push("Structures");
        tP.push("Using Java");
        tP.push("During Class");
        
        System.out.println("Object removed from stack: " + tP.pop());
        System.out.println("Output after element removal" + tP);
        
        while (!tP.empty())
            System.out.println(tP.pop());
        
        System.out.println(tP);
    }
    
    public static void testSearch(){
        
        System.out.println("\n*** TESTING SEARCH METHOD ***");
        
        Stack<String> stack = new Stack();
        stack.push("Java");
        stack.push("source");
        stack.push("code");
        
        System.out.println("The element code is in position: "
                + stack.search("code"));
        System.out.println("The element Ramon is in position: "
                + stack.search("Ramon"));
        System.out.println("");
    }
    
    public static void testRemoveElementAt(){
        
        System.out.println("\n*** TESTING REMOVE ELEMENT AT METHOD ***");
        
        Stack<Integer> nums = new Stack<>();
        
        nums.push(3);
        nums.push(-3);
        nums.push(0);
        nums.push(32);
        nums.push(-1);
        
        System.out.println("Nums stack contains: " + nums);
        
        int target = 35;
        
        if (nums.search(target) != -1){
            nums.removeElementAt(nums.size() - nums.search(target));
            System.out.println(target + " was removed from the nums stack.");
            System.out.println("Nums stack now contains: " + nums);
        } else {
            System.out.println(target + " is not in the stack.");
        }
    }
}
