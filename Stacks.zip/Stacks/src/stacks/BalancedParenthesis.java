package stacks;

import java.util.Stack;

/**
 *
 * @author ramon
 */
public class BalancedParenthesis {
    
    public static boolean isBalanced(String expression){
        
        final char LEFT_NORMAL = '(';
        final char RIGHT_NORMAL = ')';
        final char LEFT_SQUARE = '[';
        final char RIGHT_SQUARE = ']';
        final char LEFT_CURLY = '{';
        final char RIGHT_CURLY = '}';
        
        // stack used by alorithm to store parenthesis
        Stack<Character> store = new Stack();
        
        // variable used to iindicate a balance (or imbalance
        boolean imbalance = false;
        
        // loop through the expression a character at a time
        // as long as there isn't an imbalance and there is nore 
        // of the expression to loop through
        for (int i = 0; !imbalance && (i < expression.length()); i++){
            switch(expression.charAt(i)){
                case LEFT_NORMAL :
                case LEFT_CURLY :
                case LEFT_SQUARE :
                    // if the current character is a (, [, or {
                    // pushes it onto the stack
                    store.push(expression.charAt(i));
                    break;
                case RIGHT_NORMAL :
                    if (store.empty() || store.pop() != LEFT_NORMAL)
                        imbalance = true;
                    break;
                case RIGHT_CURLY :
                    if (store.empty() || store.pop() != LEFT_CURLY)
                        imbalance = true;
                    break;
                case RIGHT_SQUARE :
                    // if the current character is a ] and the stack
                    // is empty or the parenthesis at the top of the 
                    // stack isn't a [, set imbalance to true
                    if (store.empty() || store.pop() != LEFT_SQUARE)
                        imbalance = true;
                    break;
            }
        }
        
        // return true only when the stack is empty and 
        // we haven't found an imbalance
        return (store.empty() && !imbalance);
    }
}
